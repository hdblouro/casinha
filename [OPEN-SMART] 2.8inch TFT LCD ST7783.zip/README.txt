Delete all the TFT libraries you have updated, and then follow me.
Download [OPEN-SMART] 2.8inch TFT LCD ST7783.zip from
 https://drive.google.com/drive/folders/0B6uNNXJ2z4CxamVGNTk3dl9HVHc?usp=sharing
The library is compatible with Arduino UNO and MEGA2560.
/***********************************************************************************************************/
!!!NOTE:

DO NOT! DO NOT! DO NOT update directly from the Arduino IDE.

You should know that the library you update directly from the Arduino IDE is not provided by us.
Maybe it is written by somebody else.
Please follow me: and do not update from Arduino IDE
Please download the new library from the google driver. https://drive.google.com/drive/folders/0B6uNNXJ2z4CxamVGNTk3dl9HVHc?usp=sharing
All the four libraries in the folder of "Arduino library" must be put in the derectory of ../Arduino-1.xx/libraries, and then restart the IDE. 
We have test the four examples in the derectory of D:\arduino-1.6.5-r2\libraries\OPENSMART_TFT\examples\2.8inch_ST7783
/*************************************************************************************************************/

If you have any questions, please contact us: catalex_inc@163.com